package http://aehrc.com/fhir/ImplementationGuide/primary-care;

import org.hl7.fhir.r5.model.ProfilingWrapper;

public class AUPrimaryCareAllergyIntoleranceList {

}
